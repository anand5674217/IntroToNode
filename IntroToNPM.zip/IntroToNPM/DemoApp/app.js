var something=require("cat-me");

var cat=something();
console.log(cat);

//console.log("From app.js");

//var cat=something("grumpy");
//console.log(cat);


var jokes= require("knock-knock-jokes");
console.log(jokes());