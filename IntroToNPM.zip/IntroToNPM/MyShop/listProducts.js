var faker=require('faker');

faker.name.findName();
console.log(faker.commerce.productName());
for(var i=0;i<10;i++){
    console.log(faker.fake("{{faker.commerce.productName()}}, {{- }},{{faker.commerce.price()}}"))
}


console.log(faker.commerce.price());
console.log(faker.fake("Anand,Kumar"));